#!/bin/sh
cd "$(dirname "$0")"
open "./Domashka_PRO.html" 2>/dev/null || xdg-open "./Domashka_PRO.html"
