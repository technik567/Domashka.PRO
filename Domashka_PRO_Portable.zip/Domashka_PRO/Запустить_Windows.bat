@echo off
chcp 65001 >nul
start "" "%~dp0Domashka_PRO.html"
