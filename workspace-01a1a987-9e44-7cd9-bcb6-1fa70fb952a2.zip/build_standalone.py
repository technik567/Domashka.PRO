#!/usr/bin/env python3
"""
Builds a 100% self-contained single-file standalone application:
  - /home/user/Domashka_PRO.html
  - /home/user/static/Domashka_PRO.html
  - /home/user/Domashka_PRO_Portable.zip
Works directly from file:// on Windows, macOS, Linux, Android, and iOS without Python/Node/server!
"""
import base64
import glob
import os
import re
import shutil
import zipfile

ROOT = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.join(ROOT, "static", "assets")


def inline_katex_fonts(css_text: str) -> str:
    # Replace @font-face src blocks or url(/assets/*.woff2) with embedded base64 woff2
    def replace_font_face(match: re.Match) -> str:
        block = match.group(0)
        m_woff2 = re.search(r"url\((?:/assets/)?(KaTeX_[^)\"']+\.woff2)\)", block)
        if m_woff2:
            fname = m_woff2.group(1)
            fpath = os.path.join(ASSETS_DIR, fname)
            if os.path.exists(fpath):
                with open(fpath, "rb") as f:
                    b64 = base64.b64encode(f.read()).decode("ascii")
                # Replace entire src:... (with or without trailing semicolon before }) with woff2 data URI
                block = re.sub(
                    r"src:[^;}]+;?",
                    f'src:url("data:font/woff2;base64,{b64}") format("woff2");',
                    block,
                )
        else:
            # Strip any leftover /assets/KaTeX_*.woff or .ttf fallbacks when Vite already inlined woff2
            block = re.sub(r',url\(/assets/KaTeX_[^)]+\)\s*format\("[^"]+"\)', "", block)
        return block

    return re.sub(r"@font-face\{[^}]+\}", replace_font_face, css_text)


def build() -> None:
    css_files = sorted(glob.glob(os.path.join(ASSETS_DIR, "index-*.css")))
    js_files = sorted(glob.glob(os.path.join(ASSETS_DIR, "index-*.js")))
    if not css_files or not js_files:
        raise RuntimeError("Сначала выполните npm run build")

    with open(css_files[0], "r", encoding="utf-8") as f:
        css_raw = f.read()
    css_inlined = inline_katex_fonts(css_raw)

    with open(js_files[0], "r", encoding="utf-8") as f:
        js_raw = f.read()

    # Safely escape any literal </script and <!-- inside JS strings/regexes so HTML parser never breaks!
    js_safe = re.sub(r"</(script)", r"<\/\1", js_raw, flags=re.IGNORECASE)
    js_safe = js_safe.replace("<!--", "\\x3c!--")

    ver_match = re.search(
        r"APP_VERSION\s*=\s*['\"]([^'\"]+)['\"]",
        open(os.path.join(ROOT, "src", "version.js"), encoding="utf-8").read(),
    )
    app_ver = ver_match.group(1) if ver_match else "2.1"

    html = f"""<!doctype html>
<html lang="ru">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Домашка.ПРО v{app_ver} — Умный ИИ-помощник школьника (1–11 класс)</title>
  <link
    rel="icon"
    type="image/svg+xml"
    href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='16' fill='%231d4ed8'/%3E%3Cpath d='M18 14h28a4 4 0 0 1 4 4v28a4 4 0 0 1-4 4H18a4 4 0 0 1-4-4V18a4 4 0 0 1 4-4z' fill='%23fff'/%3E%3Cpath d='M23 24h18M23 32h18M23 40h12' stroke='%232563eb' stroke-width='3.5' stroke-linecap='round'/%3E%3Ccircle cx='46' cy='46' r='11' fill='%23f59e0b'/%3E%3Cpath d='M42 46l3 3 6-6' stroke='%23fff' stroke-width='3' fill='none' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E"
  />
  <style>{css_inlined}</style>
</head>
<body class="bg-slate-50 text-slate-900 antialiased selection:bg-blue-100 selection:text-blue-900">
  <div id="root"></div>
  <script>window.__STANDALONE_BUILD__ = true;</script>
  <script>{js_safe}</script>
</body>
</html>
"""

    out_main = os.path.join(ROOT, "Domashka_PRO.html")
    out_static = os.path.join(ROOT, "static", "Domashka_PRO.html")
    with open(out_main, "w", encoding="utf-8") as f:
        f.write(html)
    shutil.copyfile(out_main, out_static)

    readme_txt = """====================================================================
   ДОМАШКА.ПРО — АВТОНОМНОЕ ПРИЛОЖЕНИЕ ШКОЛЬНИКА (1–11 КЛАСС РФ)
====================================================================

КАК ЗАПУСТИТЬ (НИЧЕГО УСТАНАВЛИВАТЬ НЕ НУЖНО!):
1. Просто откройте файл «Domashka_PRO.html» двойным кликом мыши!
   Он сразу откроется в вашем браузере (Chrome, Яндекс Браузер, Edge, Safari, Firefox)
   и работает на Windows, macOS, Linux, Android и iPhone/iPad.
   Python, Node.js или какие-либо серверы устанавливать НЕ требуется!

КАК РАБОТАЕТ ИИ-ПОМОЩНИК ВНУТРИ СКАЧАННОГО ФАЙЛА:
• Режим 1 (включён сразу по умолчанию): «Встроенный бесплатный ИИ без ключа»
  — работает сразу при наличии интернета, без регистрации и без ключей!
• Режим 2: «OpenRouter Free» (кнопка в правом верхнем углу)
  — вставьте бесплатный ключ с openrouter.ai/keys для прямого чтения фото тетрадей
    и доступа к бесплатным моделям Gemma 4 31B (:free), Nemotron 3.5 VL (:free) и др.
• Режим 3: «Google Gemini Free»
  — бесплатный ключ с aistudio.google.com/apikey (идеально читает рукописный почерк
    и геометрические чертежи по фотографии).
• Режим 4: «Локальный ИИ (Ollama)» — 100% офлайн без интернета!
  — если на компьютере запущена Ollama (OLLAMA_ORIGINS=* ollama serve),
    приложение может общаться с нейросетью вообще без выхода в сеть.

ЧТО РАБОТАЕТ ДАЖЕ БЕЗ ИНТЕРНЕТА (100% ОФЛАЙН):
• Все «Точные решатели»: квадратные уравнения (дискриминант + теорема Виета),
  системы уравнений, обыкновенные дроби (5–6 кл.), НОД и НОК столбиком,
  уравнивание химических реакций и молярные массы, автоперевод в систему СИ (физика),
  перевод систем счисления и таблицы истинности (информатика ОГЭ/ЕГЭ).
• Вся база «Шпаргалок ФГОС» (1–11 классы) и счётчик слов сочинений ОГЭ/ЕГЭ.
• «Моя тетрадь» (история всех решённых заданий сохраняется прямо в вашем браузере
  с возможностью выгрузки в .json файл).
"""

    win_bat = '@echo off\r\nchcp 65001 >nul\r\nstart "" "%~dp0Domashka_PRO.html"\r\n'
    mac_cmd = '#!/bin/sh\ncd "$(dirname "$0")"\nopen "./Domashka_PRO.html" 2>/dev/null || xdg-open "./Domashka_PRO.html"\n'

    zip_path = os.path.join(ROOT, "Domashka_PRO_Portable.zip")
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_main, arcname="Domashka_PRO/Domashka_PRO.html")
        zf.writestr("Domashka_PRO/КАК_ЗАПУСТИТЬ.txt", readme_txt)
        zf.writestr("Domashka_PRO/Запустить_Windows.bat", win_bat)
        info = zipfile.ZipInfo("Domashka_PRO/Запустить_Mac_Linux.command")
        info.external_attr = 0o755 << 16
        zf.writestr(info, mac_cmd)

    size_kb = os.path.getsize(out_main) / 1024
    zip_kb = os.path.getsize(zip_path) / 1024
    print(f"✅ Собрано (v{app_ver}): Domashka_PRO.html ({size_kb:.1f} KB) и Domashka_PRO_Portable.zip ({zip_kb:.1f} KB)")


if __name__ == "__main__":
    build()
