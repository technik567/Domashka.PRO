import {
  safeStorage,
  chatStore,
  subscribeHistory,
  saveInputDraft,
  loadInputDraft,
  getStudentStats,
  recordStudentActivity,
  mistakeStore,
  subscribeMistakes,
} from './standalone/storageEngine';
import { runExactToolJS, autoVerifyMathJS } from './standalone/exactSolvers';
import {
  fetchFreeModelsBrowser,
  buildSystemPrompt,
  buildCheckerPrompt,
  generateAiBrowser,
  generatePracticeQuizBrowser,
  generateExamVariantBrowser,
  generateMistakeDrillBrowser,
} from './standalone/aiClient';
import {
  fileToDataUri,
  transformImageCanvas,
  recognizeHomeworkPhoto,
} from './standalone/visionEngine';
import { runLocalExpressCheck } from './standalone/localDraftPreCheck';

const SETTINGS_KEY = 'domashka_pro_ai_settings_v2';
const PROFILE_KEY = 'domashka_pro_student_profile_v2';
const THEME_KEY = 'domashka_pro_theme_v3';

export const DEFAULT_AI_SETTINGS = {
  provider: 'builtin', // 'builtin' | 'openrouter' | 'gemini' | 'custom'
  openrouterKey: '',
  openrouterModel: 'openrouter/free',
  geminiKey: '',
  geminiModel: 'gemini-2.5-flash',
  customBaseUrl: 'http://localhost:11434/v1',
  customModel: 'qwen2.5:7b',
  customKey: '',
};

export const DEFAULT_PROFILE = {
  grade: 8,
  examGoal: 'fgos',
};

export function loadTheme() {
  return safeStorage.getItem(THEME_KEY) === 'dark' ? 'dark' : 'light';
}

export function saveTheme(theme) {
  const val = theme === 'dark' ? 'dark' : 'light';
  safeStorage.setItem(THEME_KEY, val);
  return val;
}

export function loadAiSettings() {
  try {
    const raw = safeStorage.getItem(SETTINGS_KEY);
    if (!raw) return { ...DEFAULT_AI_SETTINGS };
    return { ...DEFAULT_AI_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return { ...DEFAULT_AI_SETTINGS };
  }
}

export function saveAiSettings(settings) {
  const merged = { ...DEFAULT_AI_SETTINGS, ...settings };
  safeStorage.setItem(SETTINGS_KEY, JSON.stringify(merged));
  return merged;
}

export function loadStudentProfile() {
  try {
    const raw = safeStorage.getItem(PROFILE_KEY);
    if (!raw) return { ...DEFAULT_PROFILE };
    return { ...DEFAULT_PROFILE, ...JSON.parse(raw) };
  } catch {
    return { ...DEFAULT_PROFILE };
  }
}

export function saveStudentProfile(profile) {
  const merged = { ...DEFAULT_PROFILE, ...profile };
  safeStorage.setItem(PROFILE_KEY, JSON.stringify(merged));
  return merged;
}

export function getActiveAuthPayload(aiSettings) {
  const s = aiSettings || loadAiSettings();
  if (s.provider === 'openrouter' && s.openrouterKey?.trim()) {
    return {
      provider: 'openrouter',
      apiKey: s.openrouterKey.trim(),
      model: s.openrouterModel || 'openrouter/free',
      customBaseUrl: '',
      hasDirectVision: !String(s.openrouterModel || '').includes('ultra-550b'),
    };
  }
  if (s.provider === 'gemini' && s.geminiKey?.trim()) {
    return {
      provider: 'gemini',
      apiKey: s.geminiKey.trim(),
      model: s.geminiModel || 'gemini-2.5-flash',
      customBaseUrl: '',
      hasDirectVision: true,
    };
  }
  if (s.provider === 'custom') {
    return {
      provider: 'custom',
      apiKey: (s.customKey || '').trim(),
      model: (s.customModel || 'qwen2.5:7b').trim(),
      customBaseUrl: (s.customBaseUrl || 'http://localhost:11434/v1').trim(),
      hasDirectVision: false,
    };
  }
  return {
    provider: 'builtin',
    apiKey: '',
    model: '',
    customBaseUrl: '',
    hasDirectVision: false,
  };
}

export const api = {
  async getModels(refresh = false) {
    const data = await fetchFreeModelsBrowser(refresh);
    return { ok: true, ...data };
  },

  async testKey({ provider, apiKey, model, customBaseUrl }) {
    try {
      const { text, used } = await generateAiBrowser({
        provider,
        apiKey,
        model,
        customBaseUrl,
        systemPrompt: 'Отвечай одной короткой фразой на русском языке.',
        messages: [{ role: 'user', content: 'Напиши: ИИ готов помогать с домашкой!' }],
      });
      return { ok: true, message: `${used}: ${text.trim()}` };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  },

  async recognizePhoto(imageDataUri, onProgressOrOpts = {}, purposeArg = 'solve') {
    const onProgress =
      typeof onProgressOrOpts === 'function'
        ? onProgressOrOpts
        : onProgressOrOpts?.onProgress || onProgressOrOpts?.onStatus;
    const purpose =
      typeof onProgressOrOpts === 'object' && onProgressOrOpts?.purpose
        ? onProgressOrOpts.purpose
        : purposeArg || 'solve';
    const signal = typeof onProgressOrOpts === 'object' ? onProgressOrOpts?.signal : undefined;
    const res = await recognizeHomeworkPhoto(imageDataUri, { onProgress, purpose, signal });
    return { ok: true, ...res };
  },

  async solveHomework({
    grade,
    examGoal,
    subject,
    mode,
    taskText,
    imageBase64,
    imagesList,
    ocrText,
    provider,
    apiKey,
    model,
    customBaseUrl,
    onStatus,
    signal,
  }) {
    const cleanTask = (taskText || '').trim();
    let cleanOcr = (ocrText || '').trim();
    const allImgs = Array.isArray(imagesList) && imagesList.length > 0 ? imagesList : imageBase64 ? [imageBase64] : [];
    if (!cleanTask && allImgs.length === 0 && !cleanOcr) {
      return { ok: false, error: 'Напишите задание, надиктуйте голосом или добавьте фотографию.' };
    }

    onStatus?.({ stage: 'prepare', message: 'Проверяем формулы и готовим запрос по программе ФГОС...' });

    try {
      // If >= 2 photos attached and OCR hasn't been pre-extracted yet, scan all attached pages in order!
      if (allImgs.length > 1 && !cleanOcr) {
        const pageTexts = [];
        for (let i = 0; i < allImgs.length; i += 1) {
          const rec = await recognizeHomeworkPhoto(allImgs[i], {
            purpose: 'solve',
            signal,
            onProgress: (st) =>
              onStatus?.({
                stage: 'vision',
                message: `Читаем фото ${i + 1} из ${allImgs.length}: ${st?.message || 'сканирование...'}`,
              }),
          });
          if (rec?.text) pageTexts.push(`[Фото ${i + 1}]:\n${rec.text}`);
        }
        cleanOcr = pageTexts.join('\n\n');
      }

      const sympyBadge = autoVerifyMathJS(cleanTask || cleanOcr);
      const sysPrompt = buildSystemPrompt(grade, examGoal, subject, mode, sympyBadge);
      const userPrompt = cleanTask || 'Помоги решить домашнее задание с прикреплённого фото.';

      const {
        text: ansMd,
        used: providerUsed,
        extractedPhotoText,
      } = await generateAiBrowser({
        provider,
        apiKey,
        model,
        customBaseUrl,
        systemPrompt: sysPrompt,
        messages: [{ role: 'user', content: userPrompt }],
        imageB64: allImgs.length === 1 ? allImgs[0] : null,
        ocrText: cleanOcr,
        onStatus,
        fallbackMode: 'solve',
        fallbackMeta: { grade, subject },
        requiresPhotoContent: Boolean(allImgs.length > 0 && !cleanTask && !cleanOcr),
        signal,
      });

      const finalOcr = extractedPhotoText || cleanOcr;
      const recheckedSympy = sympyBadge || autoVerifyMathJS(finalOcr);

      const convMessages = [
        {
          role: 'user',
          content: userPrompt + (finalOcr ? `\n\n📷 Прочитано с фото:\n${finalOcr}` : ''),
        },
        { role: 'assistant', content: ansMd },
      ];

      const saved = await chatStore.saveNew({
        item_type: 'solve',
        grade,
        exam_goal: examGoal,
        subject,
        mode,
        task_text: cleanTask || (finalOcr ? finalOcr.slice(0, 180) : 'Задание по фото'),
        image_b64: imageBase64 || '',
        ocr_text: finalOcr,
        response_md: ansMd,
        sympy_badge: recheckedSympy,
        provider_used: providerUsed,
        messages: convMessages,
      });

      return {
        ok: true,
        id: saved.id,
        chatRecord: saved,
        markdown: ansMd,
        extractedPhotoText: finalOcr,
        sympyBadge: recheckedSympy,
        providerUsed,
        messages: convMessages,
      };
    } catch (e) {
      if (e?.name === 'AbortError') return { ok: false, aborted: true, error: '' };
      return { ok: false, error: e.message };
    }
  },

  async chatFollowup({
    grade,
    examGoal,
    subject,
    mode,
    itemType = 'solve',
    historyId,
    messages,
    action,
    question,
    provider,
    apiKey,
    model,
    customBaseUrl,
    onStatus,
    signal,
  }) {
    let promptQ = (question || '').trim();
    if (action === 'board_prep') {
      promptQ =
        'Представь, что завтра учитель вызовет меня к доске по этому заданию. Составь 3 самых вероятных вопроса учителя «на понимание» по этому решению и напиши короткие, уверенные ответы на пятёрку!';
    } else if (action === 'similar_task') {
      promptQ = `Придумай одну похожую тренировочную задачу такого же уровня (${grade} класс) с другими числами или словами, чтобы я закрепил тему. Сначала условие и подсказка, а правильный ответ в самом низу.`;
    } else if (action === 'simpler') {
      promptQ = `Объясни это же решение ещё проще, буквально «на пальцах», для ученика ${grade} класса.`;
    } else if (action === 'explain_rules') {
      promptQ = `Объясни подробнее с примерами все правила, в которых были допущены ошибки в моей работе, чтобы я больше их не допускал.`;
    }

    if (!promptQ) return { ok: false, error: 'Введите вопрос.' };

    try {
      const sysPrompt =
        itemType === 'check'
          ? buildCheckerPrompt(grade, examGoal, subject)
          : buildSystemPrompt(grade, examGoal, subject, mode);

      const nextMsgs = [...(messages || []), { role: 'user', content: promptQ }];
      const { text: reply, used: providerUsed } = await generateAiBrowser({
        provider,
        apiKey,
        model,
        customBaseUrl,
        systemPrompt: sysPrompt,
        messages: nextMsgs,
        onStatus,
        fallbackMode: itemType === 'check' ? 'check' : 'solve',
        fallbackMeta: { grade, subject },
        signal,
      });
      nextMsgs.push({ role: 'assistant', content: reply });
      if (historyId) {
        await chatStore.update(historyId, {
          messages: nextMsgs,
          response_md: nextMsgs[1]?.content || reply,
        });
      }
      return { ok: true, reply, providerUsed, messages: nextMsgs };
    } catch (e) {
      if (e?.name === 'AbortError') return { ok: false, aborted: true, error: '' };
      return { ok: false, error: e.message };
    }
  },

  async checkDraft({
    grade,
    examGoal,
    checkType = 'general',
    conditionText,
    draftText,
    imageBase64,
    imagesList,
    ocrText,
    provider,
    apiKey,
    model,
    customBaseUrl,
    onStatus,
    signal,
  }) {
    const cleanCond = (conditionText || '').trim();
    const cleanDraft = (draftText || '').trim();
    let cleanOcr = (ocrText || '').trim();
    const allImgs = Array.isArray(imagesList) && imagesList.length > 0 ? imagesList : imageBase64 ? [imageBase64] : [];

    if (!cleanDraft && allImgs.length === 0 && !cleanOcr) {
      return {
        ok: false,
        error: 'Напишите свой черновик в поле текста ИЛИ прикрепите фотографию тетради.',
      };
    }

    // 1. Instant local express check (0.01s)
    const express = runLocalExpressCheck({
      conditionText: cleanCond,
      draftText: cleanDraft || cleanOcr,
      checkType,
      grade,
    });

    const parts = [];
    if (cleanCond) parts.push(`**Условие задания / тема:**\n${cleanCond}`);
    if (cleanDraft) parts.push(`**Черновик / решение ученика:**\n${cleanDraft}`);
    if (!parts.length) parts.push('Внимательно прочитай и проверь мою домашнюю работу на прикреплённой фотографии.');
    const fullUserMsg = parts.join('\n\n');

    try {
      if (allImgs.length > 1 && !cleanOcr) {
        const pageTexts = [];
        for (let i = 0; i < allImgs.length; i += 1) {
          const rec = await recognizeHomeworkPhoto(allImgs[i], {
            purpose: 'check',
            signal,
            onProgress: (st) =>
              onStatus?.({
                stage: 'vision',
                message: `Читаем страницу тетради ${i + 1} из ${allImgs.length}: ${st?.message || 'сканирование...'}`,
              }),
          });
          if (rec?.text) pageTexts.push(`[Страница ${i + 1}]:\n${rec.text}`);
        }
        cleanOcr = pageTexts.join('\n\n');
      }

      const sysPrompt = buildCheckerPrompt(grade, examGoal, checkType);
      const {
        text: ansMd,
        used: providerUsed,
        extractedPhotoText,
      } = await generateAiBrowser({
        provider,
        apiKey,
        model,
        customBaseUrl,
        systemPrompt: sysPrompt,
        messages: [{ role: 'user', content: fullUserMsg }],
        imageB64: allImgs.length === 1 ? allImgs[0] : null,
        ocrText: cleanOcr,
        onStatus,
        fallbackMode: 'check',
        requiresPhotoContent: Boolean(allImgs.length > 0 && !cleanDraft && !cleanOcr),
        fallbackMeta: {
          conditionText: cleanCond,
          draftText: cleanDraft,
          checkType,
          grade,
        },
        signal,
      });

      const finalOcr = extractedPhotoText || cleanOcr;
      const finalExpress =
        finalOcr && !cleanDraft
          ? runLocalExpressCheck({
              conditionText: cleanCond,
              draftText: finalOcr,
              checkType,
              grade,
            })
          : express;

      const convMessages = [
        {
          role: 'user',
          content: fullUserMsg + (finalOcr ? `\n\n📷 Прочитано с фото:\n${finalOcr}` : ''),
        },
        { role: 'assistant', content: ansMd },
      ];

      const saved = await chatStore.saveNew({
        item_type: 'check',
        grade,
        exam_goal: examGoal,
        subject: checkType,
        mode: 'checker',
        title: `Проверка: ${(cleanCond || cleanDraft || finalOcr || 'Работа по фото').slice(0, 56)}`,
        task_text: cleanCond || (cleanDraft ? cleanDraft.slice(0, 160) : finalOcr.slice(0, 160) || 'Проверка по фото'),
        condition_text: cleanCond,
        draft_text: cleanDraft,
        image_b64: imageBase64 || '',
        ocr_text: finalOcr,
        response_md: ansMd,
        provider_used: providerUsed,
        messages: convMessages,
      });

      const mistakesAdded = mistakeStore.captureFromDraftCheck(ansMd, finalExpress?.findings || [], {
        checkType,
        grade,
      });
      recordStudentActivity('check', 15);

      return {
        ok: true,
        id: saved.id,
        chatRecord: saved,
        markdown: ansMd,
        express: finalExpress,
        extractedPhotoText: finalOcr,
        mistakesAdded,
        providerUsed,
        messages: convMessages,
      };
    } catch (e) {
      if (e?.name === 'AbortError') return { ok: false, aborted: true, error: '', express };
      return { ok: false, error: e.message, express };
    }
  },

  async generateQuiz({ grade, subject, topic, provider, apiKey, model, customBaseUrl, onStatus, signal }) {
    return generatePracticeQuizBrowser({
      grade,
      subject,
      topic,
      provider,
      apiKey,
      model,
      customBaseUrl,
      onStatus,
      signal,
    });
  },

  async generateExamVariant({
    grade,
    subject,
    examType,
    topic,
    provider,
    apiKey,
    model,
    customBaseUrl,
    onStatus,
    signal,
  }) {
    return generateExamVariantBrowser({
      grade,
      subject,
      examType,
      topic,
      provider,
      apiKey,
      model,
      customBaseUrl,
      onStatus,
      signal,
    });
  },

  async generateMistakeDrill({
    mistake,
    grade,
    provider,
    apiKey,
    model,
    customBaseUrl,
    onStatus,
    signal,
  }) {
    return generateMistakeDrillBrowser({
      mistake,
      grade,
      provider,
      apiKey,
      model,
      customBaseUrl,
      onStatus,
      signal,
    });
  },

  async runExactTool(payload) {
    return runExactToolJS(payload);
  },
};

export async function copyTextSafe(text) {
  const str = String(text || '');
  if (!str) return false;
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(str);
      return true;
    }
  } catch {
    // Fall back to execCommand below
  }
  try {
    const ta = document.createElement('textarea');
    ta.value = str;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    ta.style.top = '0';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  } catch {
    return false;
  }
}

export {
  chatStore,
  subscribeHistory,
  saveInputDraft,
  loadInputDraft,
  getStudentStats,
  recordStudentActivity,
  mistakeStore,
  subscribeMistakes,
  fileToDataUri,
  transformImageCanvas,
  runLocalExpressCheck,
};
