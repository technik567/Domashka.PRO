import React, { useEffect, useState } from 'react';
import {
  X,
  CheckCircle2,
  Sparkles,
  Camera,
  RefreshCw,
  KeyRound,
  ShieldCheck,
  ExternalLink,
  AlertCircle,
  Loader2,
  Cpu,
} from 'lucide-react';
import { api } from '../api';
import { APP_VERSION } from '../version';

export default function AiSettingsModal({ isOpen, onClose, settings, onSave }) {
  const [form, setForm] = useState(settings);
  const [orModels, setOrModels] = useState([]);
  const [geminiModels, setGeminiModels] = useState([]);
  const [loadingModels, setLoadingModels] = useState(false);
  const [testState, setTestState] = useState({ loading: false, ok: null, msg: '' });

  useEffect(() => {
    setForm(settings);
    setTestState({ loading: false, ok: null, msg: '' });
  }, [settings, isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    fetchModels(false);
  }, [isOpen]);

  async function fetchModels(force) {
    setLoadingModels(true);
    try {
      const data = await api.getModels(force);
      if (data.ok) {
        setOrModels(data.openrouter_free || []);
        setGeminiModels(data.gemini_free || []);
      }
    } catch {
      // ignore
    } finally {
      setLoadingModels(false);
    }
  }

  async function handleTest() {
    setTestState({ loading: true, ok: null, msg: '' });
    try {
      const payload =
        form.provider === 'openrouter'
          ? { provider: 'openrouter', apiKey: form.openrouterKey, model: form.openrouterModel }
          : form.provider === 'gemini'
          ? { provider: 'gemini', apiKey: form.geminiKey, model: form.geminiModel }
          : form.provider === 'custom'
          ? {
              provider: 'custom',
              apiKey: form.customKey,
              model: form.customModel,
              customBaseUrl: form.customBaseUrl,
            }
          : { provider: 'builtin', apiKey: '', model: '' };
      const res = await api.testKey(payload);
      if (res.ok) {
        setTestState({ loading: false, ok: true, msg: res.message });
      } else {
        setTestState({ loading: false, ok: false, msg: res.error || 'Ошибка проверки' });
      }
    } catch (e) {
      setTestState({ loading: false, ok: false, msg: e.message });
    }
  }

  function handleSaveAndClose() {
    onSave(form);
    onClose();
  }

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/65 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 w-full max-w-2xl overflow-hidden my-auto animate-fade-up">
        <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 text-white">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-5 h-5 text-amber-300" />
            <div>
              <h2 className="text-base sm:text-lg font-extrabold">Настройка ИИ и распознавания фото</h2>
              <p className="text-xs text-indigo-100">
                Бесплатный ИИ без ключей + Турбо-режим с бесплатными моделями Gemini / OpenRouter
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/15 transition"
            aria-label="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={() => {
                setForm({ ...form, provider: 'builtin' });
                setTestState({ loading: false, ok: null, msg: '' });
              }}
              className={`text-left p-3.5 rounded-xl border-2 transition ${
                form.provider === 'builtin'
                  ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/50 shadow-sm'
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-extrabold text-sm text-slate-900 dark:text-white">Без ключа (из коробки)</span>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                  Сразу работает
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Регистрация не нужна. Фото читает облачная нейросеть Vision (Qwen2.5-VL / GLM-OCR).
              </p>
            </button>

            <button
              type="button"
              onClick={() => {
                setForm({ ...form, provider: 'gemini' });
                setTestState({ loading: false, ok: null, msg: '' });
              }}
              className={`text-left p-3.5 rounded-xl border-2 transition ${
                form.provider === 'gemini'
                  ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/50 shadow-sm'
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-extrabold text-sm text-slate-900 dark:text-white">Google Gemini (Free)</span>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 inline-flex items-center gap-1">
                  <Camera className="w-3 h-3" /> Топ для почерка
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Бесплатный ключ за 30 сек: читает любой почерк, формулы и отвечает за 2 сек без очереди!
              </p>
            </button>

            <button
              type="button"
              onClick={() => {
                setForm({ ...form, provider: 'openrouter' });
                setTestState({ loading: false, ok: null, msg: '' });
              }}
              className={`text-left p-3.5 rounded-xl border-2 transition ${
                form.provider === 'openrouter'
                  ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/50 shadow-sm'
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-extrabold text-sm text-slate-900 dark:text-white">OpenRouter (:free)</span>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 inline-flex items-center gap-1">
                  <Camera className="w-3 h-3" /> Текст + Фото
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Бесплатные мультимодальные модели Gemma 4 31B, Nemotron VL и авто-роутер без оплаты.
              </p>
            </button>

            <button
              type="button"
              onClick={() => {
                setForm({ ...form, provider: 'custom' });
                setTestState({ loading: false, ok: null, msg: '' });
              }}
              className={`text-left p-3.5 rounded-xl border-2 transition ${
                form.provider === 'custom'
                  ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/50 shadow-sm'
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-extrabold text-sm text-slate-900 dark:text-white">Локальная Ollama / API</span>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-violet-100 dark:bg-violet-950 text-violet-700 dark:text-violet-300 inline-flex items-center gap-1">
                  <Cpu className="w-3 h-3" /> 100% Офлайн
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Подключение к локальной модели на вашем ПК (Ollama / LM Studio) без интернета.
              </p>
            </button>
          </div>

          {form.provider === 'builtin' && (
            <div className="rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 p-4 space-y-2 text-sm text-slate-700 dark:text-slate-200">
              <p className="font-bold text-slate-900 dark:text-white">
                Как работает базовый бесплатный режим в версии {APP_VERSION}:
              </p>
              <ul className="list-disc pl-5 space-y-1 text-xs text-slate-600 dark:text-slate-300">
                <li>
                  Работает сразу без ключей и регистрации. При частых запросах подряд (чаще раза в 45 сек) встроенная очередь плавно покажет таймер обратного отсчёта и доведёт ответ до конца без сбоев.
                </li>
                <li>
                  <strong>Фотографии тетрадей и учебников</strong> теперь автоматически распознают облачные нейросети Vision (<strong>Qwen2.5-VL / GLM-OCR</strong>), а не только простой OCR!
                </li>
                <li>
                  Хотите мгновенные ответы за 2 секунды и чтение самого сложного рукописного почерка? Выберите выше <strong>Google Gemini (Free)</strong> или <strong>OpenRouter (:free)</strong>!
                </li>
              </ul>
            </div>
          )}

          {form.provider === 'gemini' && (
            <div className="space-y-4 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <label className="text-xs font-extrabold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                  <KeyRound className="w-4 h-4 text-indigo-600" />
                  Бесплатный ключ Google AI Studio (AIzaSy...)
                </label>
                <a
                  href="https://aistudio.google.com/apikey"
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1"
                >
                  Создать бесплатный ключ за 20 сек <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              <input
                type="password"
                value={form.geminiKey || ''}
                onChange={(e) => setForm({ ...form, geminiKey: e.target.value })}
                placeholder="AIzaSy..."
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white px-3.5 py-2.5 text-sm font-mono focus:ring-2 focus:ring-indigo-500 outline-none"
              />

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-200 mb-1.5">
                  Модель Google Gemini (все читают фото и почерк!)
                </label>
                <select
                  value={form.geminiModel || 'gemini-2.5-flash'}
                  onChange={(e) => setForm({ ...form, geminiModel: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white px-3 py-2.5 text-sm outline-none"
                >
                  {geminiModels.map((m) => (
                    <option key={m.id} value={m.id}>
                      📷 {m.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {form.provider === 'openrouter' && (
            <div className="space-y-4 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <label className="text-xs font-extrabold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                  <KeyRound className="w-4 h-4 text-indigo-600" />
                  Бесплатный ключ OpenRouter (sk-or-v1-...)
                </label>
                <a
                  href="https://openrouter.ai/keys"
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1"
                >
                  Получить бесплатный ключ на openrouter.ai <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              <input
                type="password"
                value={form.openrouterKey || ''}
                onChange={(e) => setForm({ ...form, openrouterKey: e.target.value })}
                placeholder="sk-or-v1-..."
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white px-3.5 py-2.5 text-sm font-mono focus:ring-2 focus:ring-indigo-500 outline-none"
              />

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-200">
                    Бесплатная модель (:free)
                  </label>
                  <button
                    type="button"
                    onClick={() => fetchModels(true)}
                    disabled={loadingModels}
                    className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1"
                  >
                    <RefreshCw className={`w-3 h-3 ${loadingModels ? 'animate-spin' : ''}`} />
                    Обновить список
                  </button>
                </div>
                <select
                  value={form.openrouterModel || 'openrouter/free'}
                  onChange={(e) => setForm({ ...form, openrouterModel: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white px-3 py-2.5 text-sm outline-none"
                >
                  {orModels.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.vision ? '📷 ' : '📝 '}
                      {m.name} [{m.badge}]
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {form.provider === 'custom' && (
            <div className="space-y-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 p-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-200 mb-1">
                  Адрес OpenAI-совместимого API (Ollama / LM Studio)
                </label>
                <input
                  type="text"
                  value={form.customBaseUrl || 'http://localhost:11434/v1'}
                  onChange={(e) => setForm({ ...form, customBaseUrl: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white px-3.5 py-2 text-sm font-mono outline-none"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-200 mb-1">
                    Имя модели
                  </label>
                  <input
                    type="text"
                    value={form.customModel || 'qwen2.5:7b'}
                    onChange={(e) => setForm({ ...form, customModel: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white px-3.5 py-2 text-sm font-mono outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-200 mb-1">
                    API-ключ (необязательно для Ollama)
                  </label>
                  <input
                    type="password"
                    value={form.customKey || ''}
                    onChange={(e) => setForm({ ...form, customKey: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white px-3.5 py-2 text-sm font-mono outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {testState.msg && (
            <div
              className={`rounded-xl p-3 text-xs flex items-start gap-2 border ${
                testState.ok
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                  : 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-200'
              }`}
            >
              {testState.ok ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              )}
              <span>{testState.msg}</span>
            </div>
          )}

          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            Ключи надёжно хранятся только локально в вашем браузере и никому не передаются.
          </div>
        </div>

        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleTest}
            disabled={testState.loading}
            className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-100 text-slate-700 dark:text-slate-200 text-xs sm:text-sm font-bold inline-flex items-center gap-2 transition"
          >
            {testState.loading && <Loader2 className="w-4 h-4 animate-spin" />}
            Проверить соединение
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-700 text-xs sm:text-sm font-semibold"
            >
              Отмена
            </button>
            <button
              type="button"
              onClick={handleSaveAndClose}
              className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-extrabold shadow-sm"
            >
              Сохранить настройки
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
